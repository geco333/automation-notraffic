# Traffic Management Platform — Frontend

React frontend for the **Traffic Management Platform** QA automation take-home. It provides a simplified UI with mock Auth0-style login, dashboard, traffic signal configuration, and real-time WebSocket updates.

## Quick start (no backend)

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Log in with **qa@test.com** / **test1234**. The app uses mock data when the API is unavailable.

## Architecture overview

- **Stack**: React 18, TypeScript, Vite 5, React Router 6.
- **Auth**: Mock Auth0 — in-memory login (qa@test.com / test1234, admin@traffic.local / admin1234). JWT stored in `sessionStorage` as `traffic_auth_token`.
- **API**: REST calls to `/api/*` (proxied to backend in dev). Endpoints expected:
  - `GET /api/signals/` — list traffic signals
  - `GET /api/signals/:id/` — signal detail
  - `PATCH /api/signals/:id/` — update configuration (e.g. `cycle_seconds`)
  - `GET /api/alerts/` — list alerts
  - `POST /api/alerts/:id/acknowledge/` — acknowledge alert
- **WebSocket**: Connects to `/ws/device-status/?token=...` for real-time device status. Messages: `{ deviceId, status, phase?, timestamp }`.

## Main flows (for E2E)

1. **Login**: Go to `/login`, fill email/password, submit → redirect to `/dashboard`.
2. **Dashboard**: Shows user name, WebSocket status, list of signals (links to detail), recent alerts. Real-time banner when a device status update is received.
3. **Signals list**: `/signals` — list all signals, link to each detail.
4. **Signal configuration**: `/signals/:id` — view status/phase, change cycle (seconds), click "Update configuration". Backend can trigger WebSocket update; UI shows last real-time update.

## Docker

**Development (Vite, hot reload):**

```bash
docker-compose -f docker-compose.dev.yml up
```

**Production build (nginx):**

```bash
docker build -t traffic-frontend .
docker run -p 3000:80 traffic-frontend
```

For a full stack (Django + Redis + PostgreSQL + this frontend), add the backend service and point the frontend proxy to it (see `vite.config.ts` and `nginx.conf`).

## Test data (mock)

- **Users**: qa@test.com / test1234; admin@traffic.local / admin1234.
- **Signals**: If API fails, the dashboard and signals pages show 2 mock signals (Main & 5th, Oak & 3rd).

## QA take-home scope

This frontend is designed to be tested as part of a 3–4 hour take-home:

- **Part 1 (API)**: Test DRF endpoints (auth, CRUD, validation) that this UI calls.
- **Part 2 (E2E)**: Automate login → dashboard → navigate to a signal → update configuration → (optional) verify WebSocket update.
- **Part 3 (Integration)**: Test the chain device → Redis/Celery → WebSocket that drives the real-time banner.
- **Part 4 (Strategy)**: Document framework choices, scaling, CI/CD, and quality improvements.

Deliverables: `/tests` (API, E2E, integration), `conftest.py`, optional CI config, and `STRATEGY.md`. Follow up with a 30–45 min walkthrough.

---

*Assignment designed for 3–4 hours. We value a working solution with clear documentation over an incomplete one. Please track your approximate time.*
